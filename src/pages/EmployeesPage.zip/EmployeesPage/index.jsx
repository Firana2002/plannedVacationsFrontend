import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getEmployees } from '@/api/employees';
import './EmployeesPage.css';

const EmployeesPage = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    let isMounted = true;
    const loadEmployees = async () => {
      try {
        const data = await getEmployees();
        
        if (isMounted) {
          setEmployees(data);
        }
      } catch (err) {
        console.error('Error loading employees:', err);
        if (isMounted) {
          setError(err.message || 'Ошибка загрузки данных');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };
    
    loadEmployees();
    return () => { isMounted = false };
  }, []);

  const handleSearch = (e) => setSearchTerm(e.target.value.toLowerCase());

  const filteredEmployees = employees.filter(employee => {
    const fullName = `${employee.lastName} ${employee.firstName} ${employee.middleName || ''}`.toLowerCase();
    return fullName.includes(searchTerm);
  });

  if (loading) return <div className="loading-state">Загрузка...</div>;
  if (error) return <div className="error-state">Ошибка: {error}</div>;

  return (
    <div className="vacation-requests-container">
    <div className="employees-page">
      <div className="employees-page__header">
        <h1 className="employees-page__title">Сотрудники</h1>
        <div className="employees-page__controls">
          <input
            type="text"
            className="employees-page__search-input"
            placeholder="Поиск сотрудника..."
            onChange={handleSearch}
          />
          <button 
            className="employees-page__add-button"
            onClick={() => navigate('/create-vacation')}
          >
            Добавить сотрудника
          </button>
        </div>
      </div>

      <table className="employees-table">
        <thead className="employees-table__header">
          <tr>
            <th className="employees-table__header-cell">ID</th>
            <th className="employees-table__header-cell">ФИО</th>
            <th className="employees-table__header-cell">Должность</th>
            <th className="employees-table__header-cell">Отдел</th>
            <th className="employees-table__header-cell">Роль</th>
            <th className="employees-table__header-cell">Дни отпуска</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map(employee => (
            <tr 
              key={employee.employeeId} 
              onClick={() => navigate(`/employees/${employee.employeeId}`)}
              className="employees-table__row employees-table__row--clickable"
            >
              <td className="employees-table__cell">{employee.employeeId}</td>
              <td className="employees-table__cell">{`${employee.lastName} ${employee.firstName} ${employee.middleName || ''}`}</td>
              <td className="employees-table__cell">{employee.position?.name || '-'}</td>
              <td className="employees-table__cell">{employee.department?.name || '-'}</td>
              <td className="employees-table__cell">
                <span className={`role-badge role-badge--${employee.role?.nameRole.toLowerCase()}`}>
                  {employee.role?.nameRole}
                </span>
              </td>
              <td className="employees-table__cell">{employee.accumulatedVacationDays}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div></div>
  );
};

export default EmployeesPage;